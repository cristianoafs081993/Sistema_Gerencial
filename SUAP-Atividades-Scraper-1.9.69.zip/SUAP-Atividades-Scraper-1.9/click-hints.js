(function () {
  if (window.__suapeClickHintsLoaded) return;
  window.__suapeClickHintsLoaded = true;

  const ROOT_ID = 'suape-click-hints-root';
  const CLICK_HINTS_SOURCE = 'suape-click-hints';
  const INTERACTIVE_ROLES = new Set([
    'button', 'checkbox', 'combobox', 'link', 'menuitem', 'menuitemcheckbox', 'menuitemradio',
    'option', 'radio', 'searchbox', 'slider', 'spinbutton', 'switch', 'tab', 'textbox', 'treeitem',
  ]);
  const NATIVE_TAGS = new Set(['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'SUMMARY']);
  const STOP_WORDS = new Set([
    'a', 'ao', 'aos', 'as', 'com', 'da', 'das', 'de', 'do', 'dos', 'e', 'em', 'na', 'nas', 'no', 'nos',
    'o', 'os', 'ou', 'para', 'por', 'pra', 'um', 'uma', 'uns', 'umas', 'the', 'and', 'for', 'of', 'to',
  ]);
  const FORM_SELECTOR = 'input:not([type="hidden"]), select, textarea, [contenteditable="true"]';
  const CANDIDATE_SELECTOR = [
    'a[href]', 'button', 'input:not([type="hidden"])', 'select', 'textarea', 'summary',
    '[contenteditable="true"]', '[onclick]', '[role]', '[tabindex]:not([tabindex="-1"])',
  ].join(',');

  let rootEl = null;
  let statusEl = null;
  let query = '';
  let active = false;
  let hints = [];
  let hintsByElement = new Map();
  let refreshFrame = 0;
  let mutationObserver = null;

  function normalizeText(value) {
    return String(value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toUpperCase()
      .replace(/[^A-Z0-9]+/g, ' ')
      .trim();
  }

  function wordsFrom(value) {
    return normalizeText(value)
      .split(/\s+/)
      .filter((word) => word && !STOP_WORDS.has(word.toLowerCase()));
  }

  function mnemonicFromLabel(label, element) {
    const words = wordsFrom(label);
    if (words.length >= 2) return `${words[0][0]}${words[1][0]}`;
    if (words.length === 1) return words[0].slice(0, 2).padEnd(2, words[0][0]);
    if (element?.tagName === 'INPUT') return 'CP';
    if (element?.tagName === 'SELECT') return 'SL';
    if (element?.tagName === 'TEXTAREA' || element?.isContentEditable) return 'TX';
    if (element?.tagName === 'A') return 'LK';
    return 'BT';
  }

  function getDirectText(element) {
    const text = element.innerText || element.textContent || '';
    return text.replace(/\s+/g, ' ').trim();
  }

  function getAssociatedLabelText(element) {
    const labels = Array.from(element.labels || []);
    const fromLabels = labels.map(getDirectText).find(Boolean);
    if (fromLabels) return fromLabels;

    const id = element.getAttribute('id');
    if (id) {
      const explicit = document.querySelector(`label[for="${typeof CSS !== 'undefined' && CSS.escape ? CSS.escape(id) : id.replace(/"/g, '\\"')}"]`);
      const explicitText = explicit ? getDirectText(explicit) : '';
      if (explicitText) return explicitText;
    }

    const wrappingLabel = element.closest('label');
    return wrappingLabel ? getDirectText(wrappingLabel) : '';
  }

  function getVisibleLabel(element) {
    const directText = getDirectText(element);
    if (directText) return directText;

    if (element instanceof HTMLInputElement && ['button', 'image', 'reset', 'submit'].includes(element.type) && element.value) {
      return element.value;
    }

    const labelText = getAssociatedLabelText(element);
    if (labelText) return labelText;

    const placeholder = element.getAttribute('placeholder');
    if (placeholder) return placeholder;

    const childWithLabel = element.querySelector?.('[aria-label], [title], img[alt]');
    if (childWithLabel) {
      const childText = childWithLabel.getAttribute('aria-label') || childWithLabel.getAttribute('title') || childWithLabel.getAttribute('alt');
      if (childText) return childText;
    }

    return element.getAttribute('aria-label') || element.getAttribute('title') || '';
  }

  function isDisabled(element) {
    return element.matches(':disabled')
      || element.getAttribute('aria-disabled') === 'true'
      || element.closest('[inert]') !== null;
  }

  function isRendered(element) {
    if (!element.isConnected || element.hidden || element.closest('[hidden], [aria-hidden="true"]')) return false;
    const styles = window.getComputedStyle(element);
    if (styles.display === 'none' || styles.visibility === 'hidden' || styles.opacity === '0') return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isInteractiveRole(element) {
    const role = (element.getAttribute('role') || '').toLowerCase();
    return INTERACTIVE_ROLES.has(role);
  }

  function hasPointerCursor(element) {
    return window.getComputedStyle(element).cursor === 'pointer';
  }

  function isCandidate(element) {
    if (!(element instanceof HTMLElement) || element.closest(`#${ROOT_ID}`)) return false;
    if (isDisabled(element) || !isRendered(element)) return false;
    return NATIVE_TAGS.has(element.tagName)
      || element.isContentEditable
      || element.hasAttribute('onclick')
      || isInteractiveRole(element)
      || (element.hasAttribute('tabindex') && element.tabIndex >= 0)
      || hasPointerCursor(element);
  }

  function isSpecificControl(element) {
    return NATIVE_TAGS.has(element.tagName)
      || element.isContentEditable
      || isInteractiveRole(element)
      || (element.hasAttribute('tabindex') && element.tabIndex >= 0);
  }

  function hasMoreSpecificDescendant(element, candidates) {
    if (isSpecificControl(element)) return false;
    return candidates.some((candidate) => candidate !== element && element.contains(candidate) && isSpecificControl(candidate));
  }

  function isRedundantControlChild(element) {
    let parent = element.parentElement;
    while (parent && !isSpecificControl(parent) && !parent.hasAttribute('onclick')) {
      parent = parent.parentElement;
    }
    if (!parent) return false;
    if (parent.matches('a[href], button, summary')) return true;

    // A pointer cursor inherited from an ARIA control does not make its label or icon a separate action.
    if (!isSpecificControl(element) && !element.hasAttribute('onclick')) return true;

    // Select2 exposes its displayed value as a readonly textbox inside the actual combobox.
    return parent.getAttribute('role') === 'combobox'
      && element.getAttribute('role') === 'textbox'
      && element.getAttribute('aria-readonly') === 'true'
      && !element.matches(FORM_SELECTOR);
  }

  function compareByScreenPosition(left, right) {
    const leftRect = left.element.getBoundingClientRect();
    const rightRect = right.element.getBoundingClientRect();
    const topDifference = leftRect.top - rightRect.top;
    if (Math.abs(topDifference) > 4) return topDifference;
    const leftDifference = leftRect.left - rightRect.left;
    if (Math.abs(leftDifference) > 4) return leftDifference;
    return left.order - right.order;
  }

  function overlapRatio(left, right) {
    const leftRect = left.element.getBoundingClientRect();
    const rightRect = right.element.getBoundingClientRect();
    const intersectionWidth = Math.max(0, Math.min(leftRect.right, rightRect.right) - Math.max(leftRect.left, rightRect.left));
    const intersectionHeight = Math.max(0, Math.min(leftRect.bottom, rightRect.bottom) - Math.max(leftRect.top, rightRect.top));
    const intersectionArea = intersectionWidth * intersectionHeight;
    const smallerArea = Math.min(leftRect.width * leftRect.height, rightRect.width * rightRect.height);
    return smallerArea > 0 ? intersectionArea / smallerArea : 0;
  }

  function collapseOverlappingDestinationHints(nextHints) {
    const hintsByDestination = new Map();
    const independentHints = [];

    nextHints.forEach((hint) => {
      hint.destination = findLinkUrl(hint.element, true);
      if (!hint.destination) {
        independentHints.push(hint);
        return;
      }
      const group = hintsByDestination.get(hint.destination) || [];
      group.push(hint);
      hintsByDestination.set(hint.destination, group);
    });

    const representatives = [...independentHints];
    hintsByDestination.forEach((group) => {
      group.sort(compareByScreenPosition);
      const remaining = new Set(group);

      while (remaining.size) {
        const first = group.find((hint) => remaining.has(hint));
        remaining.delete(first);
        const queue = [first];

        while (queue.length) {
          const current = queue.shift();
          Array.from(remaining).forEach((candidate) => {
            if (overlapRatio(current, candidate) < 0.5) return;
            remaining.delete(candidate);
            queue.push(candidate);
          });
        }

        representatives.push(first);
      }
    });

    return representatives.sort((left, right) => left.order - right.order);
  }

  function getDocumentCandidates() {
    const elements = new Set(document.querySelectorAll(CANDIDATE_SELECTOR));
    document.querySelectorAll('*').forEach((element) => {
      if (element instanceof HTMLElement && hasPointerCursor(element)) {
        if (!element.parentElement?.closest('a[href], button, summary, select, textarea')) {
          elements.add(element);
        }
      }
    });

    const candidates = Array.from(elements)
      .filter((element) => isCandidate(element))
      .filter((element, _, all) => !hasMoreSpecificDescendant(element, all))
      .filter((element) => !isRedundantControlChild(element));

    const nextHints = candidates.map((element, order) => {
      const label = getVisibleLabel(element);
      return {
        element,
        label,
        baseCode: mnemonicFromLabel(label, element),
        code: '',
        order,
      };
    });

    return collapseOverlappingDestinationHints(nextHints);
  }

  function assignInitialCodes(nextHints) {
    const groups = new Map();
    nextHints.forEach((hint) => {
      const group = groups.get(hint.baseCode) || [];
      group.push(hint);
      groups.set(hint.baseCode, group);
    });

    groups.forEach((group, baseCode) => {
      group.sort(compareByScreenPosition);
      group.forEach((hint, index) => {
        hint.code = group.length === 1 ? baseCode : `${baseCode}${index + 1}`;
      });
    });
  }

  function allocateCode(baseCode, usedCodes) {
    if (!usedCodes.has(baseCode)) return baseCode;
    let suffix = 1;
    while (usedCodes.has(`${baseCode}${suffix}`)) suffix += 1;
    return `${baseCode}${suffix}`;
  }

  function reconcileHints(preserveExisting) {
    const nextHints = getDocumentCandidates();
    if (!preserveExisting) {
      assignInitialCodes(nextHints);
      hints = nextHints;
      hintsByElement = new Map(hints.map((hint) => [hint.element, hint]));
      return;
    }

    const usedCodes = new Set();
    nextHints.forEach((hint) => {
      const previous = hintsByElement.get(hint.element);
      if (previous) {
        hint.code = previous.code;
        usedCodes.add(hint.code);
      }
    });
    nextHints.forEach((hint) => {
      if (!hint.code) {
        hint.code = allocateCode(hint.baseCode, usedCodes);
        usedCodes.add(hint.code);
      }
    });
    hints = nextHints;
    hintsByElement = new Map(hints.map((hint) => [hint.element, hint]));
  }

  function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return rect.bottom > 0 && rect.right > 0 && rect.top < window.innerHeight && rect.left < window.innerWidth;
  }

  function matchesQuery(hint) {
    return !query || hint.code.startsWith(query);
  }

  function announce(message) {
    if (statusEl) statusEl.textContent = message;
  }

  function createRoot() {
    if (rootEl) return;
    rootEl = document.createElement('div');
    rootEl.id = ROOT_ID;
    if (typeof chrome !== 'undefined' && chrome.runtime?.getManifest) {
      rootEl.dataset.extensionVersion = chrome.runtime.getManifest().version;
    }
    rootEl.hidden = true;
    rootEl.innerHTML = `
      <div class="suape-click-hints-labels" aria-hidden="true"></div>
      <div class="suape-click-hints-query" aria-hidden="true"></div>
      <div class="suape-click-hints-status" role="status" aria-live="polite"></div>
    `;
    document.documentElement.appendChild(rootEl);
    statusEl = rootEl.querySelector('.suape-click-hints-status');
  }

  function renderHints() {
    if (!rootEl || !active) return;
    const labelsEl = rootEl.querySelector('.suape-click-hints-labels');
    const queryEl = rootEl.querySelector('.suape-click-hints-query');
    labelsEl.replaceChildren();

    let visibleCount = 0;
    let matchingCount = 0;
    hints.forEach((hint) => {
      if (!isInViewport(hint.element)) return;
      visibleCount += 1;
      const matches = matchesQuery(hint);
      if (matches) matchingCount += 1;

      const rect = hint.element.getBoundingClientRect();
      const label = document.createElement('span');
      label.className = `suape-click-hint${matches ? '' : ' suape-click-hint-hidden'}`;
      label.dataset.code = hint.code;
      label.textContent = hint.code;
      label.style.left = `${Math.max(4, Math.min(rect.left, window.innerWidth - 52))}px`;
      label.style.top = `${Math.max(4, Math.min(rect.top - 8, window.innerHeight - 28))}px`;
      labelsEl.appendChild(label);
    });

    queryEl.textContent = query
      ? `${query} · Enter abrir · Ctrl+Enter nova aba`
      : 'Digite o atalho · Enter abrir · Ctrl+Enter nova aba · Esc sair';
    if (query) {
      announce(matchingCount === 1 ? `Atalho ${query}. Um ponto correspondente.` : `Atalho ${query}. ${matchingCount} pontos correspondentes.`);
    } else {
      announce(`Modo de atalhos ativado. ${visibleCount} pontos visíveis.`);
    }
  }

  function scheduleRefresh(reconcile) {
    if (!active || refreshFrame) return;
    refreshFrame = window.requestAnimationFrame(() => {
      refreshFrame = 0;
      if (reconcile) reconcileHints(true);
      renderHints();
    });
  }

  function startObserving() {
    if (mutationObserver) return;
    mutationObserver = new MutationObserver((records) => {
      const changedPage = records.some((record) => {
        const target = record.target instanceof Element ? record.target : null;
        if (!target?.closest(`#${ROOT_ID}`)) return true;
        return Array.from(record.addedNodes).some((node) => !(node instanceof Element) || !node.closest(`#${ROOT_ID}`));
      });
      if (changedPage) scheduleRefresh(true);
    });
    mutationObserver.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['hidden', 'disabled', 'aria-disabled', 'aria-hidden', 'class', 'style'] });
    window.addEventListener('scroll', handleViewportChange, true);
    window.addEventListener('resize', handleViewportChange, true);
  }

  function stopObserving() {
    mutationObserver?.disconnect();
    mutationObserver = null;
    window.removeEventListener('scroll', handleViewportChange, true);
    window.removeEventListener('resize', handleViewportChange, true);
  }

  function handleViewportChange() {
    scheduleRefresh(false);
  }

  function openHints() {
    createRoot();
    query = '';
    active = true;
    rootEl.hidden = false;
    reconcileHints(false);
    renderHints();
    startObserving();
  }

  function closeHints(message) {
    if (!active) return;
    active = false;
    query = '';
    if (refreshFrame) {
      window.cancelAnimationFrame(refreshFrame);
      refreshFrame = 0;
    }
    stopObserving();
    if (rootEl) {
      rootEl.hidden = true;
      rootEl.querySelector('.suape-click-hints-labels').replaceChildren();
    }
    announce(message || 'Modo de atalhos encerrado.');
  }

  function toggleHints() {
    if (active) closeHints('Modo de atalhos encerrado.');
    else openHints();
  }

  function findLinkUrl(element, allowFragments = false) {
    if (!element || !(element instanceof Element)) return null;

    const anchor = element.closest('a[href]')
      || (element.tagName === 'A' && element.hasAttribute('href') ? element : null)
      || element.querySelector('a[href]');

    if (anchor) {
      const rawHref = anchor.getAttribute('href') || anchor.href;
      if (rawHref && (allowFragments || !rawHref.startsWith('#')) && !rawHref.toLowerCase().startsWith('javascript:')) {
        try {
          return new URL(rawHref, window.location.href).href;
        } catch {
          if (anchor.href && !anchor.href.toLowerCase().startsWith('javascript:')) {
            return anchor.href;
          }
        }
      }
    }

    const datasetElement = element.closest('[data-href], [data-url]') || element;
    const dataUrl = datasetElement.getAttribute('data-href') || datasetElement.getAttribute('data-url');
    if (dataUrl && (allowFragments || !dataUrl.startsWith('#')) && !dataUrl.toLowerCase().startsWith('javascript:')) {
      try {
        return new URL(dataUrl, window.location.href).href;
      } catch {
        // ignore
      }
    }

    const onclick = element.getAttribute('onclick') || '';
    if (onclick) {
      const match = onclick.match(/(?:window\.open|location\.href\s*=)\s*['"]([^'"]+)['"]/);
      if (match && match[1] && (allowFragments || !match[1].startsWith('#')) && !match[1].toLowerCase().startsWith('javascript:')) {
        try {
          return new URL(match[1], window.location.href).href;
        } catch {
          // ignore
        }
      }
    }

    return null;
  }

  function openLinkInNewTab(element) {
    const url = findLinkUrl(element);
    if (!url) return false;

    const fallback = () => {
      try {
        const opened = window.open(url, '_blank', 'noopener,noreferrer');
        return Boolean(opened);
      } catch {
        return false;
      }
    };

    if (typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) {
      try {
        chrome.runtime.sendMessage({ source: CLICK_HINTS_SOURCE, type: 'open-new-tab', url }, (response) => {
          if (chrome.runtime.lastError || response?.ok === false) {
            fallback();
          }
        });
        return true;
      } catch {
        fallback();
        return true;
      }
    }

    fallback();
    return true;
  }

  function activateHint(hint, openInNewTab = false) {
    closeHints(`Atalho ${hint.code} selecionado.`);
    if (openInNewTab && openLinkInNewTab(hint.element)) return;

    window.requestAnimationFrame(() => {
      if (!hint.element.isConnected) return;
      const inputType = hint.element instanceof HTMLInputElement ? hint.element.type : '';
      const inputIsAction = ['button', 'checkbox', 'image', 'radio', 'reset', 'submit'].includes(inputType);
      if (hint.element.matches(FORM_SELECTOR) && !inputIsAction) {
        try {
          hint.element.focus({ preventScroll: true });
        } catch {
          hint.element.focus();
        }
      } else {
        if (openInNewTab) {
          try {
            const clickEvent = new MouseEvent('click', {
              bubbles: true,
              cancelable: true,
              ctrlKey: true,
              metaKey: true,
            });
            hint.element.dispatchEvent(clickEvent);
            return;
          } catch {
            // fallback to click()
          }
        }
        hint.element.click();
      }
    });
  }

  function handleActiveKeydown(event) {
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      closeHints('Modo de atalhos cancelado.');
      return;
    }
    if (event.key === 'Backspace') {
      event.preventDefault();
      event.stopPropagation();
      query = query.slice(0, -1);
      renderHints();
      return;
    }
    const isEnter = event.key === 'Enter' || event.key === 'Return' || event.code === 'Enter' || event.code === 'NumpadEnter';
    if (isEnter) {
      event.preventDefault();
      event.stopPropagation();
      const matches = hints.filter(matchesQuery);
      const exactMatches = matches.filter((hint) => hint.code === query);
      const selected = exactMatches.length === 1 ? exactMatches[0] : matches.length === 1 ? matches[0] : null;
      if (selected) activateHint(selected, Boolean(event.ctrlKey || event.metaKey));
      else announce(query ? `Atalho ${query} ainda não identifica um único ponto.` : 'Digite um atalho antes de confirmar.');
      return;
    }
    if (event.altKey || event.key.length !== 1) return;

    const typed = normalizeText(event.key).replace(/\s+/g, '');
    if (!typed) return;
    event.preventDefault();
    event.stopPropagation();
    query += typed;
    renderHints();
  }

  if (window.__suapeClickHintsKeydownHandler) {
    document.removeEventListener('keydown', window.__suapeClickHintsKeydownHandler, true);
  }
  const handleDocumentKeydown = (event) => {
    const isToggle = (event.ctrlKey || event.metaKey) && !event.altKey
      && (event.key === ';' || event.code === 'Semicolon');
    if (isToggle) {
      event.preventDefault();
      event.stopPropagation();
      toggleHints();
      return;
    }
    if (active) handleActiveKeydown(event);
  };
  window.__suapeClickHintsKeydownHandler = handleDocumentKeydown;
  document.addEventListener('keydown', handleDocumentKeydown, true);
})();
